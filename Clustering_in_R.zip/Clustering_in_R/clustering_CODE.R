library(sp)
library(raster)
library(plotrix)
library(factoextra)

data = read.csv("C:/Users/HP 1030/Documents/Desktop/statistics_time_series/3967514_cluster.csv")
str(data)
names(data)
head(data)
na.omit(data)
# summary of Age column
summary(data$gender)

# summary of Age column
summary(data$age)
# standard deviation
sd(data$age)
summary(data$education)
summary(data$area)
summary(data$mileage)
summary(data$power)

# Visualization
a = table(data$gender)
#pie chart visualization 
pct = round(a/sum(a)*100)
#library plotrix
lbs = paste(c("Female","Male")," ",pct,"%",sep = " ")
pie3D(a, labels = lbs, main = "Ratio of Females vs Males")

#age distribution visualization.
hist(data$age, xlab = "Age Class", ylab = "Frequency", col = "blue", labels = F, 
     main = "Age Distribution")
boxplot(data$age, main = "Boxplot for Age", col = "#ff0066")
#Education distribution visualization.
hist(data$education, xlab = "Education Class", ylab = "Frequency", col = "blue", labels = F, 
     main = "Education Distribution")

boxplot(data$education, main = "Boxplot for Education", col = "#ff0066")

#area
hist(data$area, xlab = "Area Class", ylab = "Frequency", col = "blue", labels = F, 
     main = "Area Distribution")
boxplot(data$area, main = "Boxplot for Area", col = "#ff0066")
# MILAGE 
hist(data$comfort, xlab = "Comfort Class", ylab = "Frequency", col = "blue", labels = F, 
     main = "Comfort Distribution")
boxplot(data$comfort, main = "Boxplot for comfort", col = "#ff0066")

# Power
hist(data$environment, xlab = "Environment Class", ylab = "Frequency", col = "blue", labels = F, 
     main = "Environment Distribution")
boxplot(data$environment, main = "Boxplot for Environment", col = "#ff0066")

# ----------------------------------K-means Algorithm
# 1. Elbow Method

library(STARTS)
library(dplyr)
library(ggplot2)
library(ggfortify)
#View(data)
mydata = select(data,c(3,4,5,6,7,8,9,10,11,12))

wssplot <- function(data, nc = 15, seed =1234)
{
  wss <- (nrow(data)[3:11])*sum(apply(data,2,var))
  for (i in 2:nc){
    set.seed(seed)
    wss[i] <- sum(kmeans(data,centers=i)$withinss)}
  plot(1:nc, wss, type ="b", xlab = "Number of clusters",
       ylab = "with of cluster", main = "Clustering Elbow Method")
  }
wssplot(mydata)
#clustering
KM = kmeans(mydata,4)
#cluster plot
autoplot(KM,mydata, frame=T, lable = data$gender) 
KM$centers

#plot_trial <- ggvegan(KM, mydata)
#p <- ggplot(data = KM,mydata, aes(x = power, gender, colour = Score)) + 
#  geom_point() + 
#  geom_text(aes(label = gender), nudge_y = 0.3)
#p
# Gap Statistic Method
# compute gap statistic method
library(cluster)
set.seed(125)

stat_gap <- clusGap(data[,3:12], FUN = kmeans, nstart = 25,
                    K.max = 10, B = 50)
fviz_gap_stat(stat_gap)

# taking k = 4 as it fits most appropriate

# compute gap statistics
k4 <- kmeans(data[,3:12],4, nstart = 50, iter.max = 100, algorithm = "Lloyd")
k4$size

plot(k4$size,
     xlab = "Cluster", 
     ylab = "Size",
     pch = 19,
     col = "red",
     main = "SIZE")
# Visualizing the clustering results using 
# the first two principle components
pcclust = prcomp(data[,3:12],scale = FALSE)
# principle component analysis
summary(pcclust)
pcclust$rotation[,1:2]

# Visualize the cluster
set.seed(134)
ggplot(data, aes(x = , y = environment))+
  geom_point(stat = "identity", aes(color = as.factor(k6$cluster)))+
  scale_color_discrete(name = " ",breaks = c("1","2","3","4"), 
                       labels= c("Cluster1","Cluster2","Cluster3",
                                 "Cluster4"))+
  ggtitle("Segement: Education vs Environment", 
          )

library(ClusterR)
library(cluster)
m1 <- data[,3:11]
set.seed(56)
kmeans.re <- kmeans(m1, centers = 4, nstart = 20)
kmeans.re
# Cluster identification for 
# each observation
kmeans.re$cluster
# Confusion Matrix
cm <- table(data$environment, kmeans.re$cluster)
cm
## Visualizing clusters
y_kmeans <- kmeans.re$cluster
clusplot(m1[, c("gender", "design")],
         y_kmeans,
         lines = 0,
         shade = F,
         color = TRUE,
         #labels = 2,
         plotchar = FALSE,
         span = F,
         main = paste("Cluster- Design and Gender"),
         xlab = 'gender',
         ylab = 'design')
library(factoextra)

iris = read.csv("C:/Users/HP 1030/Documents/Desktop/statistics_time_series/3967514_cluster.csv")
# iris.labels
#iris.labels = iris$entertainment
#table(iris.labels)
iris_data <- iris[3:12]
#View(iris)
# Scale data
iris_data_scale <- scale(iris_data)
# Distance
iris_data <- dist(iris_data_scale)

# Calculate how many clusters you need
# Within Sum Squares
fviz_nbclust(iris_data_scale, kmeans, method = "wss")+
  labs(subtitle="Elbow Method")

# Kmeans
km.out <- kmeans(iris_data_scale, centers=4,nstart=100)
print(km.out)

# Visualize the clustering algorithm results.
km.clusters<-km.out$cluster
rownames(iris_data_scale)
fviz_cluster(list(data=iris_data_scale, 
                  cluster = km.clusters, 
                  pointsize = 0.5,
                  labelsize = 0.5
),stand = F, repel = T,main = "General Clustering",
legend(xlab = area, ylab = gender))

